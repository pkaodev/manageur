#!/bin/sh

echo "Settings up Manageur"